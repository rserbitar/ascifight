from fastapi import FastAPI
from pydantic import BaseModel, validator
from collections import defaultdict
import asyncio
import itertools


MAPSIZE = 100

app = FastAPI()

command_queue = asyncio.Queue()


class Request(BaseModel):
    name: str
    password: str


class Coordinates(BaseModel):
    x: int
    y: int

    @validator("x", "y")
    def value(cls, v):
        if not (0 <= v < MAPSIZE):
            raise ValueError("Coordinates out of bounds.")
        return v


class AttackRequest(Request):
    actor: int
    direction: str

    @validator("direction")
    def check_compliance(cls, v):
        assert v in ["left", "right", "up", "down"], f"{v} is not a direction"
        return v


class MoveRequest(Request):
    actor: int
    direction: str

    @validator("direction")
    def check_compliance(cls, v):
        assert v in ["left", "right", "up", "down"], f"{v} is not a direction"
        return v


class RegisterRequest(BaseModel):
    name: str
    password: str


class Player(BaseModel):
    name: str
    password: str


class StateResponse(BaseModel):
    fields: list[list]
    players: dict[str, Player]
    time_of_next_execution: float


class GameBoard:
    def __init__(self, n, max_players):
        self.n = n
        self.max_players = max_players
        self.fields = [[0 for _ in range(n)] for _ in range(n)]
        self.players = {}
        self.time_of_next_execution = 0.0

    def validate(self, request: Request) -> bool:
        return self.players[request.name].password == request.password

    def execute_gamestep(self) -> None:
        pass


board = GameBoard(MAPSIZE, 10)


@app.post("/command")
async def command(request: MoveRequest | AttackRequest):
    command_queue.put_nowait(request)
    return {"message": "Command added."}


@app.post("/register")
async def register(request: RegisterRequest):
    if len(board.players) >= board.max_players:
        return {"message": "Maximum number of players reached"}
    board.players[request.name] = Player(name=request.name, password=request.password)
    return {"message": "Successfully registered"}


@app.get("/state")
async def get_state():
    return StateResponse(
        fields=board.fields,
        players=board.players,
        time_of_next_execution=board.time_of_next_execution,
    )


async def routine():
    while len(board.players) < board.max_players:
        await asyncio.sleep(1)
    while True:
        board.execute_gamestep()
        board.time_of_next_execution = asyncio.get_running_loop().time() + 10
        await asyncio.sleep(10)


# @app.on_event("startup")
# async def startup():
#    asyncio.create_task(routine())
