from fastapi import FastAPI
from pydantic import BaseModel, validator
from collections import defaultdict
import asyncio
import itertools


MAPSIZE = 100


app = FastAPI()


queue_move = asyncio.Queue()
queue_build_industry = asyncio.Queue()
queue_build_science = asyncio.Queue()


class Coordinates(BaseModel):
    x: int
    y: int

    @validator("x", "y")
    def value(cls, v):
        if not (0 <= v < MAPSIZE):
            raise ValueError("Coordinates out of bounds.")
        return v


class Resources(BaseModel):
    alpha: int
    beta: int
    gamma: int
    delta: int


class Request(BaseModel):
    name: str
    password: str


class BuildRequest(Request):
    coordinates: Coordinates
    amount: int
    resources: Resources | None = None


class MoveRequest(Request):
    coordinates: Coordinates
    amount: int
    direction: str

    @validator("direction")
    def check_compliance(cls, v):
        assert v in ["left", "right", "up", "down"], f"{v} is not a direction"
        return v


class RegisterRequest(BaseModel):
    name: str
    password: str


class Player(BaseModel):
    name: str
    password: str
    resources: Resources = Resources(alpha=0, beta=0, gamma=0, delta=0)
    research: int = 0


class FieldProperties(BaseModel):
    resources: Resources
    industry: int
    science: int
    military: dict[str, int]
    owner: Player | None = None


class StateResponse(BaseModel):
    fields: list[list[FieldProperties]]
    players: dict[str, Player]
    time_of_next_execution: float


class GameBoard:
    def __init__(self, n, max_players):
        self.n = n
        self.max_players = max_players
        self.fields = [
            [
                FieldProperties(
                    resources=Resources(alpha=0, beta=0, gamma=0, delta=0),
                    industry=0,
                    science=0,
                    military=defaultdict(int),
                    owner=None,
                )
                for _ in range(n)
            ]
            for _ in range(n)
        ]
        self.players = {}
        self.time_of_next_execution = 0.0

    def validate(self, request: Request) -> bool:
        return self.players[request.name].password == request.password

    def move(self) -> None:
        while not queue_move.empty():
            request: MoveRequest
            request = queue_move.get_nowait()
            if not self.validate(request):
                return
            field = self.fields[request.coordinates.x][request.coordinates.y]
            if not field.owner.name == request.name:
                return
            if field.military.get(request.name, 0) > request.amount:
                field.military[request.name] -= request.amount
                x, y = request.coordinates.x, request.coordinates.y
                match request.direction:
                    case "left":
                        x = (x - 1) % self.n
                    case "right":
                        x = (x + 1) % self.n
                    case "up":
                        y = (y + 1) % self.n
                    case "down":
                        y = (y - 1) % self.n
                destination = self.fields[x][y]
                destination.military[request.name] += request.amount

    def build_industry(self) -> None:
        while not queue_build_industry.empty():
            request: BuildRequest
            request = queue_build_industry.get_nowait()
            if not self.validate(request):
                return
            # process build industry request
            print("Build industry request processed")

    def build_science(self) -> None:
        while not queue_build_science.empty():
            request: BuildRequest
            request = queue_build_science.get_nowait()
            if not self.validate(request):
                return
            # process build science request
            print("Build science request processed")

    def assign_resources(self) -> None:
        for x, y in itertools.product(range(self.n), repeat=2):
            field = self.fields[x][y]
            if field.owner is not None:
                player = field.owner
                player.resources.alpha += field.resources.alpha
                player.resources.beta += field.resources.beta
                player.resources.gamma += field.resources.gamma
                player.resources.delta += field.resources.delta

    def combat(self) -> None:
        """If there are multiple military units in a field, remove from the strongest the second strongest number
        and remove all but the strongest
        """
        for x, y in itertools.product(range(self.n), repeat=2):
            field = self.fields[x][y]
            if len(field.military) > 1:
                sorted_military = sorted(
                    field.military.items(), key=lambda x: x[1], reverse=True
                )
                remaining = sorted_military[0][1] - sorted_military[1][1]
                field.military = (
                    {sorted_military[0][0]: remaining}
                    if remaining
                    else defaultdict(int)
                )

    def send_resources(self) -> None:
        pass

    def publish_communication(self) -> None:
        pass

    def do_research(self) -> None:
        for x, y in itertools.product(range(self.n), repeat=2):
            field = self.fields[x][y]
            if field.owner:
                field.owner.research += field.science

    def execute_gamestep(self) -> None:
        self.move()
        self.combat()
        self.build_industry()
        self.build_science()
        self.send_resources()
        self.assign_resources()
        self.do_research()
        self.publish_communication()


board = GameBoard(MAPSIZE, 10)


@app.post("/move")
async def move(request: MoveRequest):
    queue_move.put_nowait(request)
    return {"message": "Move added to queue"}


@app.post("/build_industry")
async def build_industry(request: BuildRequest):
    queue_build_industry.put_nowait(request)
    return {"message": "Build industry added to queue"}


@app.post("/build_science")
async def build_science(request: BuildRequest):
    queue_build_science.put_nowait(request)
    return {"message": "Build science added to queue"}


@app.post("/register")
async def register(request: RegisterRequest):
    if len(board.players) >= board.max_players:
        return {"message": "Maximum number of players reached"}
    board.players[request.name] = Player(
        name=request.name,
        password=request.password,
        resources=Resources(alpha=0, beta=0, gamma=0, delta=0),
    )
    return {"message": "Successfully registered"}


@app.get("/state")
async def get_state():
    return StateResponse(
        fields=board.fields,
        players=board.players,
        time_of_next_execution=board.time_of_next_execution,
    )


async def routine():
    while len(board.players) < board.max_players:
        await asyncio.sleep(1)
    while True:
        board.execute_gamestep()
        board.time_of_next_execution = asyncio.get_running_loop().time() + 10
        await asyncio.sleep(10)


@app.on_event("startup")
async def startup():
    asyncio.create_task(routine())
