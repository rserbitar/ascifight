# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['skynet']

package_data = \
{'': ['*']}

install_requires = \
['fastapi>=0.89.1,<0.90.0', 'pydantic>=1.10.4,<2.0.0']

setup_kwargs = {
    'name': 'skynet',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'serbitar',
    'author_email': 'serbitar@sessionmob.de',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
